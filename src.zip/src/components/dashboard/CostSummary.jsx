import React from 'react';

/**
 * CostSummary component displays high-level cost metrics and KPIs
 * @param {Object} props - Component props
 * @param {Object} props.data - Application data containing cost and usage metrics
 * @param {Object} props.chartData - Processed chart data for visualization
 */
const CostSummary = ({ data, chartData }) => {
  // Calculate summary metrics
  const calculateSummaryMetrics = () => {
    if (!data?.structure || !chartData) {
      return {
        totalCost: 0,
        totalApplications: 0,
        totalUsers: 0,
        averageCostPerUser: 0,
        averageCostPerApp: 0,
        costBreakdown: []
      };
    }

    // Initialize summary values
    let totalCost = 0;
    let totalApplications = 0;
    let totalUsers = new Set();
    const businessUnitCosts = {};

    // Process structure data
    Object.entries(data.structure).forEach(([groupName, groupData]) => {
      if (groupData.flexeraData) {
        // Add to total cost
        const groupCost = groupData.flexeraData.metrics?.totalCost || 0;
        totalCost += groupCost;

        // Track business unit costs
        const businessUnit = groupName.split('>')[0].trim();
        if (!businessUnitCosts[businessUnit]) {
          businessUnitCosts[businessUnit] = 0;
        }
        businessUnitCosts[businessUnit] += groupCost;

        // Add unique users to set
        if (Array.isArray(groupData.flexeraData.items)) {
          groupData.flexeraData.items.forEach(item => {
            const email = item['Assigned user - Email'];
            if (email) totalUsers.add(email);
          });
          
          // Count unique applications
          const uniqueApps = new Set();
          groupData.flexeraData.items.forEach(item => {
            const appName = item['Application - Product'];
            if (appName) uniqueApps.add(appName);
          });
          totalApplications += uniqueApps.size;
        }
      }
    });

    // Calculate averages
    const userCount = totalUsers.size;
    const averageCostPerUser = userCount > 0 ? totalCost / userCount : 0;
    const averageCostPerApp = totalApplications > 0 ? totalCost / totalApplications : 0;

    // Prepare cost breakdown for visualization
    const costBreakdown = Object.entries(businessUnitCosts).map(([unit, cost]) => ({
      name: unit,
      value: cost,
      percentage: totalCost > 0 ? (cost / totalCost) * 100 : 0
    })).sort((a, b) => b.value - a.value);

    return {
      totalCost,
      totalApplications,
      totalUsers: userCount,
      averageCostPerUser,
      averageCostPerApp,
      costBreakdown
    };
  };

  const metrics = calculateSummaryMetrics();

  // Find most efficient and least efficient applications
  const getEfficiencyInsights = () => {
    const allApps = [...chartData.top, ...chartData.least, ...chartData.costliest]
      .filter((app, index, self) => 
        index === self.findIndex(a => a.name === app.name)
      )
      .filter(app => app.users > 5); // Filter out very small use cases

    const mostEfficient = [...allApps]
      .filter(app => app.totalCost > 0)
      .sort((a, b) => (a.totalCost / a.users) - (b.totalCost / b.users))
      .slice(0, 3);

    const leastEfficient = [...allApps]
      .filter(app => app.totalCost > 1000) // Filter out very low cost apps
      .sort((a, b) => (b.totalCost / b.users) - (a.totalCost / a.users))
      .slice(0, 3);

    return { mostEfficient, leastEfficient };
  };

  const { mostEfficient, leastEfficient } = getEfficiencyInsights();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      {/* Summary KPI Cards */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Cost Summary</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="text-sm text-blue-700">Total Cost</h4>
            <p className="text-2xl font-bold">${metrics.totalCost.toLocaleString()}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="text-sm text-green-700">Applications</h4>
            <p className="text-2xl font-bold">{metrics.totalApplications.toLocaleString()}</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <h4 className="text-sm text-purple-700">Total Users</h4>
            <p className="text-2xl font-bold">{metrics.totalUsers.toLocaleString()}</p>
          </div>
          <div className="bg-amber-50 p-4 rounded-lg">
            <h4 className="text-sm text-amber-700">Avg Cost/User</h4>
            <p className="text-2xl font-bold">${metrics.averageCostPerUser.toLocaleString(undefined, {maximumFractionDigits: 2})}</p>
          </div>
        </div>

        <div className="mt-6">
          <h4 className="text-md font-semibold mb-2">Business Unit Cost Breakdown</h4>
          <div className="space-y-2">
            {metrics.costBreakdown.slice(0, 5).map((unit, index) => (
              <div key={index} className="flex items-center">
                <div className="w-24 font-medium">{unit.name}</div>
                <div className="flex-1 mx-2">
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-blue-600 h-2.5 rounded-full" 
                      style={{ width: `${unit.percentage}%` }}
                    ></div>
                  </div>
                </div>
                <div className="w-32 text-right text-sm">
                  ${unit.value.toLocaleString()} 
                  <span className="text-gray-500 ml-1">
                    ({unit.percentage.toFixed(1)}%)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Efficiency Insights */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Cost Efficiency Insights</h3>
        
        <div className="mb-6">
          <h4 className="text-md font-semibold mb-2">Most Cost-Efficient Applications</h4>
          <div className="space-y-2">
            {mostEfficient.map((app, index) => (
              <div key={index} className="p-3 bg-green-50 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-medium">{app.name}</span>
                  <span className="text-green-700 font-bold">
                    ${(app.totalCost / app.users).toLocaleString(undefined, {maximumFractionDigits: 2})}/user
                  </span>
                </div>
                <div className="text-sm text-gray-600 mt-1">
                  ${app.totalCost.toLocaleString()} total cost | {app.users} users | {app.accesses} accesses
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-md font-semibold mb-2">Least Cost-Efficient Applications</h4>
          <div className="space-y-2">
            {leastEfficient.map((app, index) => (
              <div key={index} className="p-3 bg-red-50 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="font-medium">{app.name}</span>
                  <span className="text-red-700 font-bold">
                    ${(app.totalCost / app.users).toLocaleString(undefined, {maximumFractionDigits: 2})}/user
                  </span>
                </div>
                <div className="text-sm text-gray-600 mt-1">
                  ${app.totalCost.toLocaleString()} total cost | {app.users} users | {app.accesses} accesses
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CostSummary;